<?php
// Email Submit
// Note: filter_var() requires PHP >= 5.2.0
if ( isset($_POST['email']) && isset($_POST['name']) && isset($_POST['subject']) && isset($_POST['message']) && filter_var($_POST['email'], FILTER_VALIDATE_EMAIL) ) {

// detect & prevent header injections
$test = "/(content-type|bcc:|cc:|to:)/i";
foreach ( $_POST as $key => $val ) {
if ( preg_match( $test, $val ) ) {
  exit;
}
  }

$to = "info@tilegroutmiracle.com";
$subject = 'You received a new message from Tile Grout Miracle: ' . $_POST['subject'];
$message = "You received a new mail from Tile Grout Miracle\n";
$message .= "Name: " . $_POST['name'] . "\n";
$message .= "Reply to: " . $_POST['email'] . "\n";
$message .= "Subject: " . $_POST['subject'] . "\n";
$message .= "Message: " . $_POST['message'] . "\n";
  //send email
  mail( $to, $subject, $message, "From:" . $_POST['email'] );

}
?>